
public class UpandLowcase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Java = new String ("Java is an Object Orientated programming language:");
	    System.out.println("Upper case: "+Java.toUpperCase());
	    System.out.println("Lower case: "+Java.toLowerCase());
	
			
	
		

		}
}
	
	
	
	
	

