
public class ToUppercase {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Java = new String ("Java is an Object Orientated programming language:");
	    
	
			
		
		
	String JavaU = Java.toUpperCase();
		System.out.println(JavaU);
		

		}
}
	
	
	
	
	

