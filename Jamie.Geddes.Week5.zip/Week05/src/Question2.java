import java.util.*;
public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		int num;
		String input;
		int repeat;
		String repeated;
		String firstname;
		String lastname;
		
		
		System.out.println("1.Repeat");
		System.out.println("2.initials");
		System.out.println("3.Middle names");
		System.out.println("4.Reverse");
		System.out.println("5.Dashes");
		System.out.println("6.Passwords;");
		
		
		num = scan.nextInt();
		// read and discard the newline
		scan.nextLine();
		
		
		if((num ==1)){ // repeat
		System.out.println("Enter input: ");
		input = scan.next();
		
		System.out.println("Repeat how many?:");
		repeat = scan.nextInt();
		repeated = new String(new char[repeat]).replace("\0", input);
		System.out.println(repeated);
		}
		
		
		
		else if((num ==2)){ // Initials
		System.out.println("Enter full name: ");
		input = scan.nextLine();
		input = " "+input;
		String upper = input.toUpperCase();
	  System.out.print("output = ");
		
	//	System.out.println(l);
		char x;
		for(int i=0; i<input.length();i++) {
			x = input.charAt(i);
			if(x==' '){
				System.out.print(input.charAt(i+1)+".");
		
			}
			
		}
	
		
		
			
			
		}
		
		
		else if((num ==3)){	//middle name
		
		
System.out.println("Enter a full name:");       

        String fullname = scan.nextLine();
        int firstspace = fullname.indexOf(" ");
        int lastspace = fullname.lastIndexOf(" ");
        String middlename = fullname.substring(firstspace,lastspace);
System.out.println("Your middle name is: "+middlename);
		}

		
		
		else if((num ==4)){ // Reverse
			System.out.println("Enter Your name");
			String fullname = scan.nextLine();
			String rev = new StringBuffer(fullname).reverse().toString();
			System.out.println(rev);
			
		}
		
		
		
		
		else if((num ==5)){ // Dashes
			System.out.println("Enter Your Name");
			String fullname = scan.nextLine();
			 
			int length = fullname.length();
			length = length -1;
			for(int i=0; i<length; i++){
				System.out.print(fullname.charAt(i) + "-");
			}
			System.out.println(fullname.charAt(length));
		}
		
		
		
		else if((num ==6)){ // Passwords
			System.out.println("Enter a 8 length password with 2 upper case letters, 2 lower case and a number no spaces allowed, if u do they will be removed: ");
			String password = scan.nextLine();
			password.replaceAll("\\s","");
			
			int upperCase = 0;
			int lowerCase = 0;
			int digit = 0;
			
			for (int i = 0; i < password.length(); i++) {
				char c = password.charAt(i);
			if (Character.isUpperCase(c)){
				upperCase++;
			}
			if (Character.isLowerCase(c)){
				lowerCase++;
			}
			if (Character.isDigit(c)) {
				  digit++;
				 } 
				// check if c is uppercase, if so add 1 to uppercase
				// similarly for lower case, numbers, spaces
			}
			
			if (upperCase<2){
				System.out.print("You need more Uppercase letters in password");
			}
			
			if (lowerCase<2){
				System.out.print("You need more lowercase letters in password");
			}
			// check the counts & decide whether password is good...
			
		
			
			if (digit<1){
				System.out.print("You need more numbers in password");
			}
		
			
			boolean greater8  = password.length() >= 8;
			
			
	
		}
		
		
		
		
		}	
		
		
        
       
        
        
        
		}
	

	
	
	
	

