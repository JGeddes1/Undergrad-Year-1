import java.util.Scanner;
public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      Scanner scan = new Scanner(System.in);
      System.out.println("Enter a String of numbers");
       String str = scan.nextLine();
        
        int sum = 0;
        char q;
        int a=0; 
        int z=0;
        String string;
        
        for(int i=0; i<str.length();i++){
        	q= str.charAt(i);
        	if(Character.isDigit(q)){
        		string=Character.toString(q);
        		z=Integer.parseInt(string);
        			a=a+z;
        	}
        }
        System.out.println(a);
	}
}
	
