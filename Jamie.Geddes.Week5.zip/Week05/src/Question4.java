import java.util.Scanner;
public class Question4 {
public static void prefix(){
	Scanner scan = new Scanner(System.in);
	System.out.println("Enter first word");
	String word1=scan.nextLine();
	
	System.out.println("Enter second word");
	String word2=scan.nextLine();


if(word1.charAt(0) ==word2.charAt(0)){ ///This and the else are repeated for each word to check if the words are equal and are prefix
	System.out.print(word1.charAt(0));
}	   
else{
	System.out.println("There is No common Prefix");
}
if(word1.charAt(1) == word2.charAt(1)){
	System.out.print(word1.charAt(1));
}
else{
	System.out.println("There is No common Prefix");
}
if(word1.charAt(2) == word2.charAt(2)){
	System.out.print(word1.charAt(2));
}
else{
	System.out.println("There is No common Prefix");
}
if(word1.charAt(3) == word2.charAt(3)){
	System.out.print(word1.charAt(3));
}
}

	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
    prefix();
           
        
        
		}
	}

	
	
	
	
	

