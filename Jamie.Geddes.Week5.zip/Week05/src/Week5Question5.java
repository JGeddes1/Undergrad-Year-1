
public class Week5Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
         String word1 = "Elegant man";
         String word2 = "A gentleman";

		word1 = word1.replaceAll("\\s",""); //remove all spaces
        word1 = word1.toLowerCase(); //makes all char same casing
        
        
        word2 = word2.replaceAll("\\s",""); //remove spaces
        word2 = word2.toLowerCase();// makes all lower case

        char[] wordsort = word1.toCharArray(); //formulae that sorts the words into order of alphabet 
        for (int i = 0; i <(wordsort.length - 1); i = i + 1) {
        for (int j = i + 1; j>0; j=j - 1) {
        	if (wordsort[j] < wordsort[j - 1]) {
        		//swap
        		char temp = wordsort[j];
        		wordsort[j] = wordsort[j-1];
        		wordsort[j-1]=temp;
        	}
        }
        }
        
        String sortedWord = String.valueOf(wordsort);
        word1=sortedWord;
        System.out.println(sortedWord);
        
        char[] wordsort2 = word2.toCharArray();
        for (int i = 0; i <(wordsort2.length - 1); i = i + 1) {//formulae that sorts the words into order of alphabet 
        for (int j = i + 1; j>0; j=j - 1) {
        	if (wordsort2[j] < wordsort2[j - 1]) {
        		char temp = wordsort2[j];
        		wordsort2[j] = wordsort2[j-1];
        		wordsort2[j-1]=temp;
        	}
        }
        }
        
        String sortedWord2 = String.valueOf(wordsort2);
        System.out.println(sortedWord2);
        word2=sortedWord2;
        
        if (word1.equalsIgnoreCase(word2)){
        	System.out.println("This word is an anagram of another String");
        }
        else {
        	System.out.println("This word is not an anagram!");
        }
        
        
       
        
        
        
		}
	}

	
	
	
	
	

