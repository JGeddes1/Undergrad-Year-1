
public class Index {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Java = new String ("Java is an Object Orientated programming language:");
	    String Orientated = "Orientated";
	int index;
			
	System.out.print("Found Index :");
	System.out.println(index = Java.indexOf(Orientated));

	
	
		

		}
}
	
	
	
	
	

