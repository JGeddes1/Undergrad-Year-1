
public class StringLength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Java = new String ("Java is an Object Orientated programming language:");
	    
	
			
		
		
	int JavaU = Java.length();
		System.out.println(JavaU);
		

		}
}
	
	
	
	
	

