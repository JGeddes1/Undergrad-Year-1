
public class WhiteSpaces {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String Java = new String ("Java is an Object Orientated programming language:");
	    
	
			
		
		
	String JavaU = Java.replaceAll("\\s","");
		System.out.println(JavaU);
		

		}
}
	
	
	
	
	

