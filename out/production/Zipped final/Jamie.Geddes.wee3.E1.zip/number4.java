import java.util.Scanner;
public class number4 {

	public static void main(String[] args)
	{
		 int n=1;
		 int number = 5;
		 int factorial=1;
		 for(n=1;n<=number;n++){
			 factorial=factorial*n;
		 }
	System.out.println("factor of "+number+" is:"+factorial);
	}

   
	

}
