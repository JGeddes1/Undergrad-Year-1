import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class Question4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Scanner scan = new Scanner(System.in);
		Random random = new Random();
		String[] guesses = {"woop", "Program", "please"}; //the different words used
		//SETUP
		boolean areweplaying =true;
		while (areweplaying)  {
			System.out.println("Welcome to Hangman");
			char[] randomWordToGuess = guesses[random.nextInt(guesses.length)].toCharArray(); //Take word from array then take a random number from the words using the random next int to get the words
			int amountOfGuesses = 8;       //this sets the guesses to 8                            // the char array will turn woop into w,o,o,p
			char[] playerGuess = new char[amountOfGuesses];
			
			for(int i=0;i<playerGuess.length;i++){ 
				playerGuess[i] = '_';
			}
			
			boolean wordIsGuessed = false;
			int tries = 0;
			
			while (!wordIsGuessed && tries != amountOfGuesses){ // while word is not guessed and tries not equal to amount of guesses execute
				System.out.print("Current guesses: ");
				printArray(playerGuess);
				System.out.printf("you have %d tries left. \n", amountOfGuesses - tries); // shows how many tries are left 
				System.out.println("Enter a single character");
				char input = scan.nextLine().charAt(0); //user enters a char and only recognises the first
				tries++;
				
				if (input == '-'){ //if user wants to quit they press -
					areweplaying = false; //takes us to end of program
					wordIsGuessed = true; //word is considered guessed
				} else {
					for(int i=0;i<randomWordToGuess.length;i++){
						if(randomWordToGuess[i] == input){
							playerGuess[i]=input;
						}
					
					}
					if (isTheWordGuessed(playerGuess)){ //if word is guessed
						wordIsGuessed = true;
						System.out.println("congrats you won");
					}
					
				}
				
			
				
			}
			
			if (!wordIsGuessed) System.out.println("You ran out of tries"); //checks is we ran out of guesses if so 
			
			
		}
	
		System.out.println("Game over");
	}
		public static void printArray(char[] array) {
			for(int i=0;i<array.length;i++){
				System.out.print(array[i] +" ");
			}
			System.out.println();
		}
		
		public static boolean isTheWordGuessed(char[] array) {
			for(int i=0;i<array.length;i++){
				if (array[i] == '_') return false;
			}
			return true;
		}
		
	}

		
		
		
		
		
		
		
		
		
		
		
	

	
	

