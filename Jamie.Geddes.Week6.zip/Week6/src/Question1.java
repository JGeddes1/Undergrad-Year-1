import java.util.*;
public class Question1 {

	public static void exit(){
		System.exit(0);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		boolean inUse=true;
		Scanner scan=new Scanner(System.in);
		while(inUse==true){
		
			int num = 0;
		System.out.println("1.Repeat");
		System.out.println("2.initials");
		System.out.println("3.Middle names");
		System.out.println("4.Reverse");
		System.out.println("5.Dashes");
		System.out.println("6.Passwords;");
		 System.out.print("7.To exit the program");
		
		while (true) {

            String input = scan.next();
            try {
                    num = Integer.parseInt(input);
                    break;
            } catch (NumberFormatException ne) {
                    System.out.println("Incorrect input please enter an integer.");
            }
		}
		
	
	 switch (num){
	 
	 case 1:
		 repeat();
		 break;
	 case 2:
		 initials();
		 break;
	 case 3:
		 middlename();
		 break;
	 case 4:
		 reverse();
	     break;
	 case 5:
		 Dashes();
		 break;
	 case 6:
		 passwords();
		 break;
	 case 7:
		 exit();
		 break;
	     
	 }
		}
         
	 }
		public static void repeat(){ //repeat
			Scanner scan = new Scanner(System.in);
			String input;
			int repeat;
			String repeated;
			String firstname;
			String lastname;	
		System.out.println("Enter input: ");
		input = scan.next();
		
		System.out.println("Repeat how many?:");
		repeat = scan.nextInt();
		repeated = new String(new char[repeat]).replace("\0", input);
		System.out.println(repeated);
		}
		
		
		
		public static void initials(){ // Initials
		System.out.println("Enter full name: ");
		String input;
		Scanner scan = new Scanner(System.in);
		input = scan.nextLine();
		input = " "+input;
		String upper = input.toUpperCase();
	  System.out.print("output = ");
		
	//	System.out.println(l);
		char x;
		for(int i=0; i<input.length();i++) {
			x = input.charAt(i);
			if(x==' '){
				System.out.print(input.charAt(i+1)+".");
		
			}
			
		}
	
		
		
			
			
		}

		
		public static void middlename(){
			//middle name
		
			Scanner scan = new Scanner(System.in);
			String firstname;
			String lastname;
System.out.println("Enter a full name:");       

        String fullname = scan.nextLine();
        int firstspace = fullname.indexOf(" ");
        int lastspace = fullname.lastIndexOf(" ");
        String middlename = fullname.substring(firstspace,lastspace);
System.out.println("Your middle name is: "+middlename);
		}

		
		
		public static void reverse(){ // Reverse
			Scanner scan = new Scanner(System.in);
			int num;
			String input;
			String firstname;
			String lastname;
			System.out.println("Enter Your name");
			String fullname = scan.nextLine();
			String rev = new StringBuffer(fullname).reverse().toString();
			System.out.println(rev);
			
		}
		
		
		
		
		public static void Dashes(){ // Dashes
			Scanner scan = new Scanner(System.in);
			int num;
			String input;
			int repeat;
			String repeated;
			String firstname;
			String lastname;
			System.out.println("Enter Your Name");
			String fullname = scan.nextLine();
			 
			int length = fullname.length();
			length = length -1;
			for(int i=0; i<length; i++){
				System.out.print(fullname.charAt(i) + "-");
			}
			System.out.println(fullname.charAt(length));
		}
		
		
		
		public static void passwords(){ // Passwords
			Scanner scan = new Scanner(System.in);
	
			System.out.println("Enter a 8 length password with 2 upper case letters, 2 lower case and a number no spaces allowed, if u do they will be removed: ");
			String password = scan.nextLine();
			password.replaceAll("\\s","");
			
			int upperCase = 0;
			int lowerCase = 0;
			int digit = 0;
			
			for (int i = 0; i < password.length(); i++) {
				char c = password.charAt(i);
			if (Character.isUpperCase(c)){
				upperCase++;
			}
			if (Character.isLowerCase(c)){
				lowerCase++;
			}
			if (Character.isDigit(c)) {
				  digit++;
				 } 
				// check if c is uppercase, if so add 1 to uppercase
				// similarly for lower case, numbers, spaces
			}
			
			if (upperCase<2){
				System.out.print("You need more Uppercase letters in password");
			}
			
			if (lowerCase<2){
				System.out.print("You need more lowercase letters in password");
			}
			// check the counts & decide whether password is good...
			
		
			
			if (digit<1){
				System.out.print("You need more numbers in password");
			}
		
			
			boolean greater8  = password.length() >= 8;
			
			
	
		}
		
		
		
		
		}	
		
		
        
       
        
        
        
		
	

	
	
	
	

