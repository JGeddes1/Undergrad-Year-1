
public class Question2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		reverse();	
		
		
	}	
		

	static int[] reverse() {
		// TODO Auto-generated method stub
		int[] numbers = new int[5];
		numbers[0]=1;
		numbers[1]=2;
		numbers[2]=3;
		numbers[3]=4;
		numbers[4]=5;
		
		for(int i=0;i<numbers.length;i++){
			System.out.print(numbers[i] + " ");
		}

		for(int i = numbers.length; i > 0 ; i--){
	        System.out.print(numbers[i-1] + " ");
		
	    
		
		}
		return numbers;
	
		}
		

	}


	
	
	
	
	

