import java.util.Arrays;


public class Question3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		reverse();	
		
		
	}	
		

	static int[] reverse() {
		// TODO Auto-generated method stub
		int[] numbers = new int[200];
		Arrays.fill(numbers, 10);
		for(int i=0; i<numbers.length+i; ++i);
		System.out.print(numbers);
		return numbers;
		
		

	}

}



	
	
	
	
	

