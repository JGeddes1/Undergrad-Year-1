import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;


public class Question5 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		double loaning;
		double interestrate;
		double monthlypay;
		double repay;
		
		
		System.out.println("How much is the loan");
		loaning = scan.nextDouble();
		
		System.out.println("What is the interest on the loan?");
		interestrate=scan.nextDouble();
		
		System.out.println("What is the min monthly payback ?");
		monthlypay = scan.nextDouble();
		
		int i=0;
		while(loaning>0){
			System.out.println(" ");
			System.out.println("Month "+i);
			System.out.println("Left to pay  "+loaning);
			System.out.println("How much pay back? ");
			repay=scan.nextDouble();
			while((repay<monthlypay) &&! (loaning<monthlypay));{
				System.out.println("Error, you must pay back £"+monthlypay+" or more");
				System.out.println("How much will you payback");
				repay=scan.nextDouble();
			}
			loaning=loaning-repay;
			loaning=loaning+(loaning*(interestrate/100));
			if(i>0){
				System.out.println("Interest applied: "+(loaning*(interestrate/100)));
			}
			i++;
			if(loaning<=0){
				System.out.println(" ");
				System.out.print("Month :"+(i));
				System.out.println(" Left to pay: "+0);
				return;
			}
		}
		
	}
}