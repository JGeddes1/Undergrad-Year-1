import java.util.*;
public class Week7Q3 {

	// based on the specified start point, offer the appropriate
	// list of endpoints
	public static void offerEnds(int journ) {
		switch (journ){
		case 1://If Manchester is beggining
			System.out.println("Please select the end Journey");
			System.out.println("1. York");
			System.out.println("2. Leeds");
			System.out.println("3. Hull");
			break;
		case 2://If York is beggining
			System.out.println("Please select the end Journey");
			System.out.println("1. Manchester");
			System.out.println("2. Leeds");
			System.out.println("3. Hull");
			break;
		case 3://If Leeds is beggining
			System.out.println("Please select the end Journey");
			System.out.println("1. Manchester");
			System.out.println("2. York");
			System.out.println("3. Hull");
			break;
		case 4://If Hull is beggining
			System.out.println("Please select the end Journey");
			System.out.println("1. Manchester");
			System.out.println("2. York");
			System.out.println("3. Leeds");
			break;
		}
	}

	// offer possible starting points for a journey
	public static void offerStarts() {
		System.out.println("Please select the Starting Journey");
		System.out.println("1. Manchester");
		System.out.println("2. York");
		System.out.println("3. Leeds");
		System.out.println("4. Hull");
	}
	
	public static void costs() { // a confirm your destinations
		System.out.println("Please confirm the trip and price for journey:");
		System.out.println("1. Machester to York");
		System.out.println("2. Manchester to Leeds");
		System.out.println("3. Manchester to Hull");
		System.out.println("4. York to Manchester");
		System.out.println("5. York to Leeds");
		System.out.println("6. York to Hull");
		System.out.println("7. Leeds to Manch");
		System.out.println("8. Leeds to York");
		System.out.println("9. Leeds to Hull");
		System.out.println("10. Hull to Manch");
		System.out.println("11. Hull to York");
		System.out.println("12. Hull to Leeds");
	}
	
	public static String cost[] = { //cost for return
		
		// Machester to York 
		"27.50",
		// Manchester to Leeds 
		"25.50",
		// Manchester to Hull
		"35",
		// York to Manch
		"24",
		// York to Leeds
		"12.45",
		// York to Hull
		"18.50",
		//Leeds to Manch
		"15.60",
		// Leeds to York
		"12.45",
		// Leeds to hull
		"8.45",
		// Hull to Manch
		"35",
		// Hull to York
		"18.50"
	
		
	};
	
	public static String costoneway[] = { //cost for one way
			// Machester to York 
			"5.80",
			// Manchester to Leeds 
			"10.22",
			// Manchester to Hull
			"8.78",
			// York to Manch
			"8.32",
			// York to Leeds
			"6.67",
			// York to Hull
			"8.50",
			//Leeds to Manch
			"15.60",
			// Leeds to York
			"12.45",
			// Leeds to hull
			"8.45",
			// Hull to Manch
			"23.23",
			// Hull to York
			"11.50"
		
			
		};


	public static String ticketTypes[] = {
			"under 10",
			"under 16",
			"student",
			"over 60",
			"other"
	};
	// THE JOURNEYS AND IF YOU PICKED DIFFERENT DESTINATION WOULD TAKE YOU TO A DIFFERENT ONE
	public static String startjourn[] = {
			"Manchester",
			"York",
			"Leeds",
			"Hull"
	};
	
	public static String endjourn[] = {
			
			"York",
			"Leeds",
			"Hull"
	};
	
	public static String endjourn1[] = {
			"Manchester",
			"Leeds",
			"Hull"
	};
	
	public static String endjourn2[] = {
			"York",
			"Hull",
			"Manchester"
	};
	
	public static String endjourn3[] = {
			"York",
			"Leeds",
			"Hull"
	};
	
	//TICKET TYPE
	public static String tickettyp[] = {
			"Return",
			"One way"
	};
	


	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		//TICKETS AMOUNT
		System.out.println("How many tickets you want?");
		int ticketnumber = scan.nextInt(); 
		if(ticketnumber>10){
			System.out.println("Error please restart.");
		System.exit(ticketnumber); // if too many put in stops the program
		}
		//BEING ASKED FOR TICKET TYPE
		System.out.println("You picked " + ticketnumber);
		System.out.println("Please select the type of ticket you want");
		System.out.println("1. Return");
		System.out.println("2. One way");
		int types = scan.nextInt(); //the input of user on what type of ticket
		System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]); //showing the user which has been selected
		String typeticket;

		switch (types){

		case 1: //IF CHOSEN RETURN
			System.out.println("What passenger type of Ticket?");
			System.out.println("1. under 10 ");
			System.out.println("2. under 16 ");
			System.out.println("3. Student ");
			System.out.println("4. Over 60 ");
			System.out.println("5. Other");

			int passenger = scan.nextInt(); //this is what takes the users input and saves it for the type of passenger they are
			System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
			System.out.println("You picked " + ticketTypes[passenger - 1]);
			//this above shows the previous choice and their passenger type choice
			switch (passenger){
// THE DIFFERENT PASSENEGER TICKETS OPTIONS
			case 1:// if picked under 10
				offerStarts(); //loads the offer starts method
				int journ = scan.nextInt();
				offerEnds(journ); //loads the offer ends method
				int finaljour =scan.nextInt();
				costs(); //loads the cost method
				int booking = scan.nextInt();
			
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger - 1]);
				System.out.println("You picked " + startjourn[journ - 1]);
				System.out.println("You picked " + endjourn[finaljour-1]);
				System.out.println("The cost each ticket will be £" + cost[booking - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 2: //if picked under 16
				offerStarts();
				int journ1 = scan.nextInt();
				offerEnds(journ1);
				int finaljour1 =scan.nextInt();
				costs();
				int booking1 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger - 1]);
				System.out.println("You picked " + startjourn[journ1 - 1]);
				System.out.println("You picked " + endjourn1[finaljour1-1]);
				System.out.println("The cost each ticket will be £" + cost[booking1 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
		    	// System.out.println("The cost of journey is...." + cost[journ1-1]+[journ2-1]);
				break;
			case 3: // if picked Student
				offerStarts();
				int journ2 = scan.nextInt();
				offerEnds(journ2);
				int finaljour2 =scan.nextInt();
				costs();
				int booking2 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger - 1]);
				System.out.println("You picked " + startjourn[journ2 - 1]);
				System.out.println("You picked " + endjourn1[finaljour2-1]);
				System.out.println("The cost each ticket will be £" + cost[booking2 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 4: // if picked over 60
				offerStarts();
				int journ3 = scan.nextInt();
				offerEnds(journ3);
				int finaljour3 =scan.nextInt();
				costs();
				int booking3 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger - 1]);
				System.out.println("You picked " + startjourn[journ3 - 1]);
				System.out.println("You picked " + endjourn1[finaljour3-1]);
				System.out.println("The cost each ticket will be £" + cost[booking3 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 5: // if picked other
				offerStarts();
				int journ4 = scan.nextInt();
				offerEnds(journ4);
				int finaljour4 =scan.nextInt();
				costs();
				int booking4 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger - 1]);
				System.out.println("You picked " + startjourn[journ4 - 1]);
				System.out.println("You picked " + endjourn1[finaljour4-1]);
				System.out.println("The cost each ticket will be £" + cost[booking4 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			}


			scan.nextInt();


			break;

		case 2: // IF CHOSEN ONEWAY
			System.out.println("2. What passenger type of Ticket?");
			System.out.println("1. under 10");
			System.out.println("2. under 16");
			System.out.println("3. Student");
			System.out.println("4. Over 60");
			System.out.println("5. Other");

			int passenger2 = scan.nextInt();
			System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
			System.out.println("You picked " + ticketTypes[passenger2 - 1]);
			switch (passenger2){

			case 1:// if picked under 10
				offerStarts();
				int journ = scan.nextInt();
				offerEnds(journ);
				int finaljour =scan.nextInt();
				costs();
				int booking = scan.nextInt();
			
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger2 - 1]);
				System.out.println("You picked " + startjourn[journ - 1]);
				System.out.println("You picked " + endjourn[finaljour-1]);
				System.out.println("The cost each ticket will be £" + costoneway[booking - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 2: //if picked under 16
				offerStarts();
				int journ1 = scan.nextInt();
				offerEnds(journ1);
				int finaljour1 =scan.nextInt();
				costs();
				int booking1 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger2 - 1]);
				System.out.println("You picked " + startjourn[journ1 - 1]);
				System.out.println("You picked " + endjourn1[finaljour1-1]);
				System.out.println("The cost each ticket will be £" + costoneway[booking1 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 3: // if picked Student
				offerStarts();
				int journ2 = scan.nextInt();
				offerEnds(journ2);
				int finaljour2 =scan.nextInt();
				costs();
				int booking2 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger2 - 1]);
				System.out.println("You picked " + startjourn[journ2 - 1]);
				System.out.println("You picked " + endjourn1[finaljour2-1]);
				System.out.println("The cost each ticket will be £" + costoneway[booking2 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 4: // if picked over 60
				offerStarts();
				int journ3 = scan.nextInt();
				offerEnds(journ3);
				int finaljour3 =scan.nextInt();
				costs();
				int booking3 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger2 - 1]);
				System.out.println("You picked " + startjourn[journ3 - 1]);
				System.out.println("You picked " + endjourn1[finaljour3-1]);
				System.out.println("The cost each ticket will be £" + costoneway[booking3 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			case 5: // if picked other
				offerStarts();
				int journ4 = scan.nextInt();
				offerEnds(journ4);
				int finaljour4 =scan.nextInt();
				costs();
				int booking4 = scan.nextInt();
				System.out.println("You picked " + ticketnumber+" " + tickettyp[types-1]);
				System.out.println("You picked " + ticketTypes[passenger2 - 1]);
				System.out.println("You picked " + startjourn[journ4 - 1]);
				System.out.println("You picked " + endjourn1[finaljour4-1]);
				System.out.println("The cost each ticket will be £" + costoneway[booking4 - 1]);
				//THE ABOVE PRINTS ALL THE PREVIOUS STATEMENTS CHOSEN BY THE USER SO IT SHOWS THEIR RECIEPT
				break;
			}


			scan.nextInt();


			break;
			
		}



	

	}

}
