import java.util.Scanner;

public class Week7Q2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
int[] numbers = new int [10];

System.out.println("Enter " +numbers.length+ " elements");
for(int i=0; i<numbers.length; i++){
	numbers[i] = scan.nextInt();
	
	
	numbers[0] = numbers[i];
	numbers[1] = scan.nextInt();
	numbers[2] = scan.nextInt();
	numbers[3] = scan.nextInt();
	numbers[4] = scan.nextInt();
	numbers[5] = scan.nextInt();
	numbers[6] = scan.nextInt();
	numbers[7] = scan.nextInt();
	
	System.out.print("Element 1 = "+numbers[0]);
	System.out.println("Element 2 = "+numbers[1]);
	System.out.print("Element 3 = "+numbers[2]);
	System.out.println("Element 4 = "+numbers[3]);
	System.out.print("Element 5 = "+numbers[4]);
	System.out.println("Element 6 = "+numbers[5]);
	System.out.print("Element 7 = "+numbers[6]);
	System.out.println("Element  = "+numbers[7]);
	
	
}

}
	}


