import java.util.Scanner;
import java.io.*;
import java.nio.file.Path;
import java.nio.file.Paths;
public class ReadingFiles {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
Scanner scan = new Scanner(System.in);
System.out.println("please enter the name of your file");
String V = scan.next();
Path path = Paths.get(V);
if (V.exists()){
	   throw new java.io.IOException("file exists");
}

}
	}

