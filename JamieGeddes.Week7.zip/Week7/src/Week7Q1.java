
public class Week7Q1 {

	
	public static void sum() {
		int[] array= new int []{3,3,4,1,9};
		int sum = 0;
		for (int i = 0; i<array.length; i++)
			sum = sum + array[i];
	
		System.out.println("The sum of the values are "+sum);
		}
	
	
	public static void maxval() {
		int[] array=new int [] {1,2,3,4};
		int max=0;
		for(int i = 0; i<array.length; i++) {
			max = array[i];
		
			
			for (int j = i+1; j<array.length; j++) {
	            if (array[j] > max) {
	               max = array[j];	
		System.out.println("The max val is " +max);
		
	            } 
	}
		}
		}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
sum();
maxval();
	}

}
